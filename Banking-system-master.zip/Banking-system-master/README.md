# Banking-system
A simple code in C++ on banking system
Can perform basic tasks like-:
                              1).account creation
                              2).information retrieval
                              3).withdrawing
                              4).deposit
