# cgpa-calculator
*A simple c++ program to calculate CGPA*

This simple C++ program will calculate **CGPA** - Cumulative Grade Point Average.

Run the **cgpa_calculate.cpp** file using console/terminal/ or your favourite IDE.

If need, **change** the mimimum passing **GPA** or **CGPA** accourding to your academic curriculum.

**You need to input entire academic results and have to pass all the exams to caculate your CGPA.**
